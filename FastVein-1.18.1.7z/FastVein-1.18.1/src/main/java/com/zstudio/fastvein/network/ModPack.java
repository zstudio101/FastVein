package com.zstudio.fastvein.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public class ModPack {
    public ModPack(){}

    public ModPack(FriendlyByteBuf buffer){}

    public void toByte(FriendlyByteBuf buffer){}

    public void handler(Supplier<NetworkEvent.Context> ctx){}

}
