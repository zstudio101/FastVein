package com.zstudio.fastvein.network;

import com.zstudio.fastvein.events.CommonEventHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public class KeyRelease extends ModPack {
    public KeyRelease(){}

    public KeyRelease(FriendlyByteBuf buffer){}

    @Override
    public void handler(Supplier<NetworkEvent.Context> ctx){
        ctx.get().enqueueWork(
                () -> {
                    ServerPlayer playerEntity = ctx.get().getSender();
                    CommonEventHandler.uuids.removeIf(name -> {
                        assert playerEntity != null;
                        return name.equals(playerEntity.getUUID());
                    });
                }
        );
        ctx.get().setPacketHandled(true);
    }

}
