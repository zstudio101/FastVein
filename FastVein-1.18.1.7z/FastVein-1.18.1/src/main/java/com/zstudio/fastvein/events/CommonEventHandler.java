package com.zstudio.fastvein.events;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import java.util.*;

public class CommonEventHandler {
    private boolean flag = false;
    public static Set<UUID> uuids = new HashSet<>();

    @SubscribeEvent
    public void onBlockBreakEvent(BlockEvent.BreakEvent event){
        Level world = (Level) event.getWorld();
        Player player = event.getPlayer();
        BlockPos pos = event.getPos();
        if(flag)
            return;
        if((!world.getBlockState(pos).getBlock().canHarvestBlock(world.getBlockState(pos), world, pos, player) && !player.isCreative()) || !world.isLoaded(pos))
            return;
        if(!uuids.contains(player.getUUID())) {
            return;
        } else {
            flag = true;
            BlockState state = event.getState();
            ItemStack itemStack = player.getMainHandItem();
            LinkedList<BlockPos> blockPos1 = new LinkedList<>();
            HashSet<BlockPos> blockPos2 = new HashSet<>();
            blockPos1.add(pos);
            blockPos2.add(pos);
            int counts = 0;
            int sum = 16;
            int exp = event.getExpToDrop();
            while (!blockPos1.isEmpty() && counts < sum) {
                BlockPos blockPos = blockPos1.poll();
                for (int x = -1; x < 2; x ++) {
                    for (int y = -1; y < 2; y ++) {
                        for (int z = -1; z < 2; z ++) {
                            BlockPos check = blockPos.offset(x, y, z);
                            if (!blockPos2.contains(check) && world.getBlockState(check).equals(state)) {
                                blockPos1.add(check);
                                blockPos2.add(check);
                                world.destroyBlock(check, !player.isCreative());
                                if (!world.isClientSide) {
                                    if(itemStack.isDamageableItem() && !player.isCreative()){
                                        if(itemStack.getDamageValue() < itemStack.getMaxDamage()){
                                            itemStack.hurt(1, player.getRandom(), (ServerPlayer) player);
                                        }else{
                                            itemStack.hurtAndBreak(1, (ServerPlayer)player, p -> p.broadcastBreakEvent(EquipmentSlot.MAINHAND));
                                            break;
                                        }
                                    }
                                }
                                int xp = 0;
                                while(xp < exp){
                                    ExperienceOrb orb = new ExperienceOrb(world, check.getX(), check.getY(), check.getZ(), 1);
                                    world.addFreshEntity(orb);
                                    xp ++;
                                }
                            }
                        }
                    }
                }
                counts ++;
            }
            flag = false;
        }
    }
}
