package com.zstudio.fastvein;

import com.zstudio.fastvein.client.ClientEventHandler;
import com.zstudio.fastvein.events.CommonEventHandler;
import com.zstudio.fastvein.network.NetWorking;
import net.minecraftforge.client.ClientRegistry;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(FastVein.MOD_ID)
public class FastVein {
    public static final String MOD_ID = "fastvein";

    public FastVein(){
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::commonSetup);
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::clientSetup);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(NetWorking::register);
        MinecraftForge.EVENT_BUS.register(new CommonEventHandler());
    }

    private void clientSetup(final FMLClientSetupEvent evt) {
        MinecraftForge.EVENT_BUS.register(new ClientEventHandler());
        ClientRegistry.registerKeyBinding(ClientEventHandler.fastVeinKey);
    }
}
