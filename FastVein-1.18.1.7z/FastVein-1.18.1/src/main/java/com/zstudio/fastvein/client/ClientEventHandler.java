package com.zstudio.fastvein.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.zstudio.fastvein.network.KeyPress;
import com.zstudio.fastvein.network.KeyRelease;
import com.zstudio.fastvein.network.NetWorking;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

@OnlyIn(Dist.CLIENT)
public class ClientEventHandler {
    public static KeyMapping fastVeinKey = new KeyMapping("连锁键", InputConstants.KEY_GRAVE, "快捷连锁挖矿");
    private boolean flag = false;

    @SubscribeEvent
    public void onKeyInputEvent(InputEvent.KeyInputEvent event){
        if(ClientEventHandler.fastVeinKey.isDown() && !flag){
            flag = true;
            NetWorking.INSTANCE.sendToServer(new KeyPress());
        }else if(!ClientEventHandler.fastVeinKey.isDown() && flag) {
            flag = false;
            NetWorking.INSTANCE.sendToServer(new KeyRelease());
        }
    }
}
