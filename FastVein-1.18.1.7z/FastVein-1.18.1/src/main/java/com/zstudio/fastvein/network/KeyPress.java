package com.zstudio.fastvein.network;

import com.zstudio.fastvein.events.CommonEventHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public class KeyPress extends ModPack {
    public KeyPress(){}

    public KeyPress(FriendlyByteBuf buffer){}

    @Override
    public void handler(Supplier<NetworkEvent.Context> ctx){
        ctx.get().enqueueWork(
                () -> {
                    ServerPlayer playerEntity = ctx.get().getSender();
                    assert playerEntity != null;
                    CommonEventHandler.uuids.add(playerEntity.getUUID());
                }
        );
        ctx.get().setPacketHandled(true);
    }

}
