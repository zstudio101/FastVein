package com.zstudio.fastvein.network;

import com.zstudio.fastvein.FastVein;
import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;
import net.minecraft.entity.player.EntityPlayer;

public class KeyRelease extends ModPack {
    public static class Handler implements IMessageHandler<KeyRelease, IMessage> {
        @Override
        public IMessage onMessage(KeyRelease message, MessageContext ctx) {
            EntityPlayer player = ctx.getServerHandler().playerEntity;
            FastVein.VEIN_PLAYERS.removeIf(uuid -> uuid.equals(player.getUniqueID()));
            return null;
        }
    }
}
