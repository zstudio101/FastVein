package com.zstudio.fastvein.proxy;

import com.zstudio.fastvein.event.CommonEventHandler;
import com.zstudio.fastvein.network.Networking;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.common.MinecraftForge;

public class CommonProxy {
    public void preInit(FMLPreInitializationEvent event) {
        FMLCommonHandler.instance().bus().register(new CommonEventHandler());
        MinecraftForge.EVENT_BUS.register(new CommonEventHandler());
        Networking.registerMessage();
    }

    public void init(FMLInitializationEvent event) {
    }
}
