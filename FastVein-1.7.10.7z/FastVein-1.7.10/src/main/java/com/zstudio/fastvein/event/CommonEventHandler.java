package com.zstudio.fastvein.event;

import com.zstudio.fastvein.FastVein;
import com.zstudio.fastvein.util.BlockPos;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.block.Block;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.event.world.BlockEvent;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

public class CommonEventHandler {
    private static boolean flag = false;

    @SubscribeEvent
    public void onBlockBreakEvent(BlockEvent.BreakEvent event){
        World world = event.world;
        EntityPlayer player = event.getPlayer();
        BlockPos pos = new BlockPos(event.x, event.y, event.z);
        Block posBlock = world.getBlock(pos.getX(), pos.getY(), pos.getZ());
        int blockMetadata = world.getBlockMetadata(pos.getX(), pos.getY(), pos.getZ());
        if(flag)
            return;
        if((!world.getBlock(event.x, event.y, event.z).canHarvestBlock(player, blockMetadata) && !player.capabilities.isCreativeMode || !world.blockExists(event.x, event.y, event.z)))
            return;
        if(!FastVein.VEIN_PLAYERS.contains(player.getUniqueID())) {
            return;
        } else {
            flag = true;
            LinkedList<BlockPos> blockPos1 = new LinkedList<>();
            HashSet<BlockPos> blockPos2 = new HashSet<>();
            blockPos1.add(pos);
            blockPos2.add(pos);
            int counts = 0;
            int sum = 24;
            int exp = event.getExpToDrop();
            while (!blockPos1.isEmpty() && counts < sum) {
                BlockPos blockPos = blockPos1.poll();
                for (int x = -1; x < 2; x ++) {
                    for (int y = -1; y < 2; y ++) {
                        for (int z = -1; z < 2; z ++) {
                            BlockPos check = blockPos.add(x, y, z);
                            Block checkBlock = world.getBlock(check.getX(), check.getY(), check.getZ());
                            if (!blockPos2.contains(check) && checkBlock == posBlock && world.getBlockMetadata(check.getX(), check.getY(), check.getZ()) == (blockMetadata)) {
                                blockPos1.add(check);
                                blockPos2.add(check);
                                int meta = world.getBlockMetadata(check.getX(), check.getY(), check.getZ());
                                checkBlock.onBlockDestroyedByPlayer(world, check.getX(), check.getY(), check.getZ(), meta);
                                breakBlock(world, player, check);
                                if(!player.capabilities.isCreativeMode){
                                    List<ItemStack> drops = checkBlock.getDrops(world, check.getX(), check.getY(), check.getZ(), meta, 0);
                                    for (ItemStack stack : drops) {
                                        EntityItem itemEntity = new EntityItem(world, check.getX() + 0.5, check.getY() + 0.5, check.getZ() + 0.5, stack);
                                        itemEntity.delayBeforeCanPickup = 10;
                                        world.spawnEntityInWorld(itemEntity);
                                    }
                                }
                                if (!world.isRemote) {
                                    if(player.getHeldItem() != null && player.getHeldItem().isItemStackDamageable() && !player.capabilities.isCreativeMode) {
                                        if (player.getHeldItem().getItemDamage() < player.getHeldItem().getMaxDamage()) {
                                            player.getHeldItem().attemptDamageItem(1, player.getRNG());
                                        } else {
                                            player.getHeldItem().stackSize -= 1;
                                            if(player.getHeldItem().stackSize <= 0){
                                                player.destroyCurrentEquippedItem();
                                            }
                                            break;
                                        }
                                    }
                                }
                                int xp = 0;
                                while(xp < exp){
                                    EntityXPOrb orb = new EntityXPOrb(world, check.getX(), check.getY(), check.getZ(), 1);
                                    world.spawnEntityInWorld(orb);
                                    xp ++;
                                }
                            }
                        }
                    }
                }
                counts ++;
            }
            flag = false;
        }
    }

    public boolean breakBlock(World world, EntityPlayer player, BlockPos pos) {
        int blockMetadata = world.getBlockMetadata(pos.getX(), pos.getY(), pos.getZ());
        Block block = world.getBlock(pos.getX(), pos.getY(), pos.getZ());
        int xp;
        if(world.isAirBlock(pos.getX(), pos.getY(), pos.getZ()))
            return false;
        if(!ForgeHooks.canHarvestBlock(block, player, blockMetadata) && !player.capabilities.isCreativeMode)
            return false;
        if(!world.isRemote) {
            xp = ForgeHooks.onBlockBreakEvent(world, ((EntityPlayerMP)player).mcServer.getGameType(), (EntityPlayerMP)player, pos.getX(), pos.getY(), pos.getZ()).getExpToDrop();
            if(xp == -1)return false;
            if(!block.removedByPlayer(world, player, pos.getX(), pos.getY(), pos.getZ(), !player.capabilities.isCreativeMode))
                return false;
            block.onBlockDestroyedByPlayer(world, pos.getX(), pos.getY(), pos.getZ(), blockMetadata);
            if(!player.capabilities.isCreativeMode) {
                player.addExhaustion(0.005F);
            }
        } else {
            if(!block.removedByPlayer(world, player, pos.getX(), pos.getY(), pos.getZ(), !player.capabilities.isCreativeMode))
                return false;
            block.onBlockDestroyedByPlayer(world, pos.getX(), pos.getY(), pos.getZ(), blockMetadata);
        }
        return true;
    }
}
