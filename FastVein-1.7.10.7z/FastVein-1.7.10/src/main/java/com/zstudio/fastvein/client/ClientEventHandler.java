package com.zstudio.fastvein.client;

import com.zstudio.fastvein.network.Networking;
import com.zstudio.fastvein.network.KeyPress;
import com.zstudio.fastvein.network.KeyRelease;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.InputEvent;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.settings.KeyBinding;
import org.lwjgl.input.Keyboard;

@SideOnly(value = Side.CLIENT)
public class ClientEventHandler {
    public static KeyBinding fastVeinKey = new KeyBinding("连锁键",  Keyboard.KEY_GRAVE, "快捷连锁挖矿");
    public static boolean flag = false;

    @SubscribeEvent
    public void onKeyInputEvent(InputEvent.KeyInputEvent event){
        if(fastVeinKey.getIsKeyPressed() && !flag){
            flag = true;
            Networking.INSTANCE.sendToServer(new KeyPress());
        }else if(!fastVeinKey.getIsKeyPressed() && flag) {
            flag = false;
            Networking.INSTANCE.sendToServer(new KeyRelease());
        }

    }
}
