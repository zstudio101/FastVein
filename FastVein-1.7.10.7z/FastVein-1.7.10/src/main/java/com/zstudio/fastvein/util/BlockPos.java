package com.zstudio.fastvein.util;

import com.google.common.collect.AbstractIterator;
import java.util.Iterator;
import javax.annotation.concurrent.Immutable;

import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Immutable
public class BlockPos extends Vec3i {
    public BlockPos(int p_i46030_1_, int p_i46030_2_, int p_i46030_3_) {
        super(p_i46030_1_, p_i46030_2_, p_i46030_3_);
    }

    public BlockPos(double p_i46031_1_, double p_i46031_3_, double p_i46031_5_) {
        super(p_i46031_1_, p_i46031_3_, p_i46031_5_);
    }

    public BlockPos(Vec3i p_i46034_1_) {
        this(p_i46034_1_.getX(), p_i46034_1_.getY(), p_i46034_1_.getZ());
    }

    public BlockPos add(double p_add_1_, double p_add_3_, double p_add_5_) {
        return p_add_1_ == 0.0 && p_add_3_ == 0.0 && p_add_5_ == 0.0 ? this : new BlockPos((double)this.getX() + p_add_1_, (double)this.getY() + p_add_3_, (double)this.getZ() + p_add_5_);
    }

    public BlockPos add(int p_add_1_, int p_add_2_, int p_add_3_) {
        return p_add_1_ == 0 && p_add_2_ == 0 && p_add_3_ == 0 ? this : new BlockPos(this.getX() + p_add_1_, this.getY() + p_add_2_, this.getZ() + p_add_3_);
    }

    public BlockPos add(Vec3i p_add_1_) {
        return this.add(p_add_1_.getX(), p_add_1_.getY(), p_add_1_.getZ());
    }

    public BlockPos subtract(Vec3i p_subtract_1_) {
        return this.add(-p_subtract_1_.getX(), -p_subtract_1_.getY(), -p_subtract_1_.getZ());
    }

    public BlockPos up() {
        return this.up(1);
    }

    public BlockPos up(int p_up_1_) {
        return this.offset(EnumFacing.UP, p_up_1_);
    }

    public BlockPos down() {
        return this.down(1);
    }

    public BlockPos down(int p_down_1_) {
        return this.offset(EnumFacing.DOWN, p_down_1_);
    }

    public BlockPos north() {
        return this.north(1);
    }

    public BlockPos north(int p_north_1_) {
        return this.offset(EnumFacing.NORTH, p_north_1_);
    }

    public BlockPos south() {
        return this.south(1);
    }

    public BlockPos south(int p_south_1_) {
        return this.offset(EnumFacing.SOUTH, p_south_1_);
    }

    public BlockPos west() {
        return this.west(1);
    }

    public BlockPos west(int p_west_1_) {
        return this.offset(EnumFacing.WEST, p_west_1_);
    }

    public BlockPos east(int p_east_1_) {
        return this.offset(EnumFacing.EAST, p_east_1_);
    }

    public BlockPos offset(EnumFacing p_offset_1_, int p_offset_2_) {
        return p_offset_2_ == 0 ? this : new BlockPos(this.getX() + p_offset_1_.getFrontOffsetX() * p_offset_2_, this.getY() + p_offset_1_.getFrontOffsetY() * p_offset_2_, this.getZ() + p_offset_1_.getFrontOffsetZ() * p_offset_2_);
    }

    public BlockPos crossProduct(Vec3i p_crossProduct_1_) {
        return new BlockPos(this.getY() * p_crossProduct_1_.getZ() - this.getZ() * p_crossProduct_1_.getY(), this.getZ() * p_crossProduct_1_.getX() - this.getX() * p_crossProduct_1_.getZ(), this.getX() * p_crossProduct_1_.getY() - this.getY() * p_crossProduct_1_.getX());
    }

    public static Iterable<BlockPos> getAllInBox(final int p_getAllInBox_0_, final int p_getAllInBox_1_, final int p_getAllInBox_2_, final int p_getAllInBox_3_, final int p_getAllInBox_4_, final int p_getAllInBox_5_) {
        return new Iterable<BlockPos>() {
            public Iterator<BlockPos> iterator() {
                return new AbstractIterator<BlockPos>() {
                    private boolean first = true;
                    private int lastPosX;
                    private int lastPosY;
                    private int lastPosZ;

                    protected BlockPos computeNext() {
                        if (this.first) {
                            this.first = false;
                            this.lastPosX = p_getAllInBox_0_;
                            this.lastPosY = p_getAllInBox_1_;
                            this.lastPosZ = p_getAllInBox_2_;
                            return new BlockPos(p_getAllInBox_0_, p_getAllInBox_1_, p_getAllInBox_2_);
                        } else if (this.lastPosX == p_getAllInBox_3_ && this.lastPosY == p_getAllInBox_4_ && this.lastPosZ == p_getAllInBox_5_) {
                            return (BlockPos)this.endOfData();
                        } else {
                            if (this.lastPosX < p_getAllInBox_3_) {
                                ++this.lastPosX;
                            } else if (this.lastPosY < p_getAllInBox_4_) {
                                this.lastPosX = p_getAllInBox_0_;
                                ++this.lastPosY;
                            } else if (this.lastPosZ < p_getAllInBox_5_) {
                                this.lastPosX = p_getAllInBox_0_;
                                this.lastPosY = p_getAllInBox_1_;
                                ++this.lastPosZ;
                            }

                            return new BlockPos(this.lastPosX, this.lastPosY, this.lastPosZ);
                        }
                    }
                };
            }
        };
    }

    public BlockPos toImmutable() {
        return this;
    }
}