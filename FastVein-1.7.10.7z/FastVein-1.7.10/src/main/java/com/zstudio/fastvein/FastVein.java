package com.zstudio.fastvein;

import com.zstudio.fastvein.proxy.CommonProxy;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Mod(modid = FastVein.MODID)
public class FastVein
{
    public static final String MODID = "goodveinmine";
    public static final String SERVER = "com.zstudio.fastvein.proxy.CommonProxy";
    public static final String CLIENT = "com.zstudio.fastvein.proxy.ClientProxy";
    public static Set<UUID> VEIN_PLAYERS = new HashSet<>();

    @SidedProxy(clientSide = CLIENT, serverSide = SERVER)
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        proxy.preInit(event);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        proxy.init(event);
    }
}
