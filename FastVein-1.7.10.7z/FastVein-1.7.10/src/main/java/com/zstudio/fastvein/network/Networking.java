package com.zstudio.fastvein.network;

import com.zstudio.fastvein.FastVein;
import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import cpw.mods.fml.relauncher.Side;

public class Networking {
    public static SimpleNetworkWrapper INSTANCE;
    private static int ID;

    public static int nextID(){
        return ID ++;
    }

    public static void registerMessage(){
        INSTANCE = NetworkRegistry.INSTANCE.newSimpleChannel(FastVein.MODID);
        INSTANCE.registerMessage(new KeyPress.Handler(), KeyPress.class, nextID(), Side.SERVER);
        INSTANCE.registerMessage(new KeyRelease.Handler(), KeyRelease.class, nextID(), Side.SERVER);
    }
}
