package com.zstudio.fastvein.client;

import com.zstudio.fastvein.network.KeyPress;
import com.zstudio.fastvein.network.KeyRelease;
import com.zstudio.fastvein.network.NetWorking;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class ClientEventHandler {
    private boolean flag = false;
    public static KeyBinding fastVeinKey = new KeyBinding("连锁键", 96, "快捷连锁挖矿");

    @SubscribeEvent
    public void onKeyInputEvent(InputEvent.KeyInputEvent event){
        if(fastVeinKey.isKeyDown() && !flag){
            flag = true;
            NetWorking.INSTANCE.sendToServer(new KeyPress());
        }else if(!fastVeinKey.isKeyDown() && flag) {
            flag = false;
            NetWorking.INSTANCE.sendToServer(new KeyRelease());
        }
    }
}
