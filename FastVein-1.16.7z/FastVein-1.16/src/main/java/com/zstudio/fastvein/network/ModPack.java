package com.zstudio.fastvein.network;

import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.network.NetworkEvent;
import java.util.function.Supplier;

public class ModPack {
    public ModPack(){}

    public ModPack(PacketBuffer buffer){}

    public void toByte(PacketBuffer buffer){}

    public void handler(Supplier<NetworkEvent.Context> ctx){}
}
