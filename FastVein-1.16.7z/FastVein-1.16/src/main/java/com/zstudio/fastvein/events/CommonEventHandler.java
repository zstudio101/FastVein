package com.zstudio.fastvein.events;

import net.minecraft.block.BlockState;
import net.minecraft.entity.item.ExperienceOrbEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;
import java.util.UUID;

public class CommonEventHandler {
    private static boolean flag = false;
    public static Set<UUID> uuids = new HashSet<>();

    @SubscribeEvent
    public void onBlockBreakEvent(BlockEvent.BreakEvent event){
        World world = (World) event.getWorld();
        PlayerEntity player = event.getPlayer();
        BlockPos pos = event.getPos();
        if(flag)
            return;
        if((!world.getBlockState(pos).getBlock().canHarvestBlock(world.getBlockState(pos), world, pos, player) && !player.isCreative()) || !world.isBlockLoaded(pos))
            return;
        if(uuids.contains(player.getUniqueID())) {
            flag = true;
            BlockState state = event.getState();
            ItemStack itemStack = player.getHeldItemMainhand();
            LinkedList<BlockPos> blockPos1 = new LinkedList<>();
            HashSet<BlockPos> blockPos2 = new HashSet<>();
            blockPos1.add(pos);
            blockPos2.add(pos);
            int counts = 0;
            int sum = 16;
            int exp = event.getExpToDrop();
            while (!blockPos1.isEmpty() && counts < sum) {
                BlockPos blockPos = blockPos1.poll();
                for (int x = -1; x < 2; x ++) {
                    for (int y = -1; y < 2; y ++) {
                        for (int z = -1; z < 2; z ++) {
                            BlockPos check = blockPos.add(x, y, z);
                            if (!blockPos2.contains(check) && world.getBlockState(check).equals(state)) {
                                blockPos1.add(check);
                                blockPos2.add(check);
                                world.destroyBlock(check, !player.isCreative());
                                if (!world.isRemote && player.getHeldItemMainhand().isDamageable() && !player.isCreative()) {
                                    if (player.getHeldItemMainhand().getDamage() < player.getHeldItemMainhand().getMaxDamage()) {
                                        player.getHeldItemMainhand().attemptDamageItem(1, player.getRNG(), (ServerPlayerEntity) player);
                                    } else {
                                        player.sendBreakAnimation(EquipmentSlotType.MAINHAND);
                                        player.getHeldItemMainhand().shrink(1);
                                        break;
                                    }
                                }
                                int xp = 0;
                                while(xp < exp){
                                    ExperienceOrbEntity orb = new ExperienceOrbEntity(world, check.getX(), check.getY(), check.getZ(), 1);
                                    world.addEntity(orb);
                                    xp ++;
                                }
                            }
                        }
                    }
                }
                counts ++;
            }
            flag = false;
        }
    }
}
