package com.zstudio.fastvein.network;

import com.zstudio.fastvein.events.CommonEventHandler;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.network.NetworkEvent;
import java.util.function.Supplier;

public class KeyPress extends ModPack {
    public KeyPress(){}

    public KeyPress(PacketBuffer buffer){
        super(buffer);
    }

    public void handler(Supplier<NetworkEvent.Context> ctx){
        ctx.get().enqueueWork(
            () -> {
                ServerPlayerEntity player = ctx.get().getSender();
                if(player != null){
                    CommonEventHandler.uuids.add(player.getUniqueID());
                }
            }
        );
        ctx.get().setPacketHandled(true);
    }

}
