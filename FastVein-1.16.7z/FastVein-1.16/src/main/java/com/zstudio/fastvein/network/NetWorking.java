package com.zstudio.fastvein.network;

import com.zstudio.fastvein.FastVein;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.network.NetworkRegistry;
import net.minecraftforge.fml.network.simple.SimpleChannel;

public class NetWorking {
    public static SimpleChannel INSTANCE;
    public static final String VERSION = "1.0";
    private static int ID;

    public static int nextID(){
        return ID ++;
    }

    public static void register(){
        INSTANCE = NetworkRegistry.newSimpleChannel(new ResourceLocation(FastVein.MOD_ID, "fast_vein"), () -> VERSION, (version) -> version.equals(VERSION), (version) -> version.equals(VERSION));
        INSTANCE.messageBuilder(KeyPress.class, nextID()).encoder(KeyPress::toByte).decoder(KeyPress::new).consumer(KeyPress::handler).add();
        INSTANCE.messageBuilder(KeyRelease.class, nextID()).encoder(KeyRelease::toByte).decoder(KeyRelease::new).consumer(KeyRelease::handler).add();
    }
}
