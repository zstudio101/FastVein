package com.zstudio.fastvein.proxy;

import com.zstudio.fastvein.client.ClientEventHandler;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class ClientProxy extends CommonProxy {
    public void preInit(FMLPreInitializationEvent event) {
        super.preInit(event);
    }

    public void init(FMLInitializationEvent event) {
        ClientRegistry.registerKeyBinding(ClientEventHandler.fastVeinKey);
    }
}
