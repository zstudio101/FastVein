package com.zstudio.fastvein.network;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class KeyRelease extends ModPack {
    public static class Handler implements IMessageHandler<KeyRelease, IMessage>{
        @Override
        public IMessage onMessage(KeyRelease message, MessageContext ctx) {
            EntityPlayer player = ctx.getServerHandler().player;
            Networking.uuids.removeIf(uuid -> uuid.equals(player.getUniqueID()));
            return null;
        }
    }
}
