package com.zstudio.fastvein.network;

import com.zstudio.fastvein.FastVein;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class Networking {
    public static Set<UUID> uuids = new HashSet<>();
    public static SimpleNetworkWrapper INSTANCE;
    private static int ID;
    public static int nextID(){
        return ID ++;
    }

    public static void registerMessage(){
        INSTANCE = NetworkRegistry.INSTANCE.newSimpleChannel(FastVein.MODID);
        INSTANCE.registerMessage(new KeyPress.Handler(), KeyPress.class, nextID(), Side.SERVER);
        INSTANCE.registerMessage(new KeyRelease.Handler(), KeyRelease.class, nextID(), Side.SERVER);
    }
}
