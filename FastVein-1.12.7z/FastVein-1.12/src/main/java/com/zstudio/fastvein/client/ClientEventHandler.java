package com.zstudio.fastvein.client;

import com.zstudio.fastvein.network.Networking;
import com.zstudio.fastvein.network.KeyPress;
import com.zstudio.fastvein.network.KeyRelease;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.relauncher.Side;
import org.lwjgl.input.Keyboard;

@Mod.EventBusSubscriber(value = Side.CLIENT)
public class ClientEventHandler {
    public static KeyBinding fastVeinKey = new KeyBinding("连锁键",  Keyboard.KEY_GRAVE, "快捷连锁挖矿");
    public static boolean flag = false;

    @SubscribeEvent
    public static void onKeyInput(InputEvent.KeyInputEvent event){
        if(ClientEventHandler.fastVeinKey.isKeyDown() && !flag){
            flag = true;
            Networking.INSTANCE.sendToServer(new KeyPress());
        }else if(!ClientEventHandler.fastVeinKey.isKeyDown() && flag) {
            flag = false;
            Networking.INSTANCE.sendToServer(new KeyRelease());
        }

    }
}
