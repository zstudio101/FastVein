package com.zstudio.fastvein.network;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class KeyPress extends ModPack {
    public static class Handler implements IMessageHandler<KeyPress, IMessage>{
        @Override
        public IMessage onMessage(KeyPress message, MessageContext ctx) {
            EntityPlayer player = ctx.getServerHandler().player;
            Networking.uuids.add(player.getUniqueID());
            return null;
        }
    }
}
