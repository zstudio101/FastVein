package com.zstudio.fastvein.event;

import com.zstudio.fastvein.network.Networking;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.HashSet;
import java.util.LinkedList;

@Mod.EventBusSubscriber
public class CommonEventHandler {
    private static boolean flag = false;

    @SubscribeEvent
    public static void onBlockBreak(BlockEvent.BreakEvent event){
        World world = event.getWorld();
        EntityPlayer player = event.getPlayer();
        BlockPos pos = event.getPos();
        if(flag)
            return;
        if((!world.getBlockState(pos).getBlock().canHarvestBlock(world, pos, player) && !player.isCreative()) || !world.isBlockLoaded(pos))
            return;
        if(Networking.uuids.contains(player.getUniqueID())) {
            flag = true;
            IBlockState state = event.getState();
            ItemStack itemStack = player.getHeldItemMainhand();
            LinkedList<BlockPos> blockPos1 = new LinkedList<>();
            HashSet<BlockPos> blockPos2 = new HashSet<>();
            blockPos1.add(pos);
            blockPos2.add(pos);
            int counts = 0;
            int sum = 24;
            int exp = event.getExpToDrop();
            while (!blockPos1.isEmpty() && counts < sum) {
                BlockPos blockPos = blockPos1.poll();
                for (int x = -1; x < 2; x ++) {
                    for (int y = -1; y < 2; y ++) {
                        for (int z = -1; z < 2; z ++) {
                            BlockPos check = blockPos.add(x, y, z);
                            if (!blockPos2.contains(check) && world.getBlockState(check).equals(state)) {
                                blockPos1.add(check);
                                blockPos2.add(check);
                                if(player.isCreative()){
                                    world.destroyBlock(check, false);
                                }else{
                                    world.destroyBlock(check, true);
                                }
                                if (!world.isRemote && player.getHeldItemMainhand().isItemStackDamageable() && !player.isCreative()) {
                                    itemStack.damageItem(1, player);
                                }
                                int xp = 0;
                                while(xp < exp){
                                    EntityXPOrb orb = new EntityXPOrb(world, check.getX(), check.getY(), check.getZ(), 1);
                                    world.spawnEntity(orb);
                                    xp ++;
                                }
                            }
                        }
                    }
                }
                counts ++;
            }
            flag = false;
        }
    }
}
