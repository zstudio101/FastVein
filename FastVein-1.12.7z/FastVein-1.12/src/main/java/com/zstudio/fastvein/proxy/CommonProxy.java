package com.zstudio.fastvein.proxy;

import com.zstudio.fastvein.network.Networking;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class CommonProxy {
    public void preInit(FMLPreInitializationEvent event) {
        Networking.registerMessage();
    }

    public void init(FMLInitializationEvent event) {
    }
}
